import numpy as np

def calcularLU(A):
    L, U = [],[]
    P = None
    # su código
    
    ###########
    return L, U, P


def inversaLU(L, U, P=None):
    Inv = []
    # su código
    
    ###########
    return Inv
